module.exports = {
  apiUrl: "http://localhost:7000/api/",
  baseUrl: "http://localhost"
  //  /apiUrl: "http://shortener.muhzi.com/v1/api/",
  // baseUrl: "http://muhzi.com"
};
