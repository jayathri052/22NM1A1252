module.exports = {
  redisUrl: 'redis://127.0.0.1:6379',
};
