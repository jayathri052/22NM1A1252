module.exports = {
  mongoURI: "mongodb://localhost/url-shortner",
  errorUrl: "https://muhzi.com/error"
};
